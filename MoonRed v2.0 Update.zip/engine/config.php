<?php
include 'config_site.php';
include 'functions.php';
?>
