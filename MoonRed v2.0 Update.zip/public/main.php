<?
	if(!defined("moonstudio")) return header("Location: /");
?>